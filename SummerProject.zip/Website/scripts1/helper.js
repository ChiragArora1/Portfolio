var skills = '<div class="col-md-3"><img src="./img1/%data%.png" alt="My Skills" class="img-responsive img-circle"></div>';

var skills_array = ['1','2','3','4','5','6','7','8','9','10','11','12'];

var skills_new = '';

for(var i=0; i < skills_array.length; i += 1){
	skills_new = skills.replace('%data%', skills_array[i]);
	$('.skills-section-images').append(skills_new);
}

//experience Section

var experience = '<li><h4>%data% &nbsp; &nbsp; &nbsp; ( %data1% )</h4><br><h5>%data2%</h5></li><hr>';

var experience_array=[
	{
		name: 'Animation Club',
		years: '2013-2015',
		info: 'It is one of the best clubs of my school, I worked in it from 2013-2015 during my higher secondary education.',
	},
	{
		name: 'Tag Club',
		years: '2016-',
		info: 'Technology and Gaming Club is the pioneering student club in VIT University leading the student community in the sphere of gaming and game development. It organize game events like Game-a-thon and other interesting events like Studio to Stage and Build to Hack. Here, I work as a member in Management Team as well as a web developer.',
	}
];

var experience_new='';
for(var i=0; i<experience_array.length;i+=1){
	experience_new=experience.replace('%data%',experience_array[i]['name']);
	experience_new=experience_new.replace('%data1%',experience_array[i]['years']);
	experience_new=experience_new.replace('%data2%',experience_array[i]['info']);
	$('.experience-section-info').append(experience_new);
}

var projects = '<li><h3>%data%</h3><div class="row"><div class="col-md-3"><img src="./img1/%data1%.png" alt="project-images" class="img-responsive"></div><div class="col-md-9"><h3>Language(s): %data2%</h3><h5>%data3%</h5></div></li><hr>';
var projects_array = [
{
	name: 'Codecademy',
	img: 'HC',
	language: 'HTML',
	info: 'HyperText Markup Language, commonly abbreviated as HTML, is the standard markup language used to create web pages. In this summer holidays, I learnt HTML through codecademy and by watching tutorials on Youtube.'
},
{
	name: 'Codecademy',
	img: 'HC',
	language: 'CSS',
	info: 'Cascading Style Sheets (CSS) is a style sheet language used for describing the presentation of a document written in a markup language.Although most often used to set the visual style of web pages and user interfaces written in HTML and XHTML, the language can be applied to any XML document, including plain XML, SVG and XUL, and is applicable to rendering in speech, or on other media.'
},
{
	name: 'Codecademy',
	img: 'JS',
	language: 'JavaScript',
	info: 'JavaScript is a high-level, dynamic, untyped, and interpreted programming language. It has been standardized in the ECMAScript language specification. Alongside HTML and CSS, it is one of the three core technologies of World Wide Web content production; the majority of websites employ it. After learning these basics of these 3 languages, I have created my own website.'
}
];

var projects_new='';
for (var i=0; i<projects_array.length;i+=1){
	projects_new = projects.replace('%data%',projects_array[i]['name']);
	projects_new = projects_new.replace('%data1%',projects_array[i]['img']);
	projects_new = projects_new.replace('%data2%',projects_array[i]['language']);
	projects_new = projects_new.replace('%data3%',projects_array[i]['info']);
	$('.projects-section-info').append(projects_new);
};